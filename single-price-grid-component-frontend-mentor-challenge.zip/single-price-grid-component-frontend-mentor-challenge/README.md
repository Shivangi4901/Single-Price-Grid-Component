# Single Price Grid Component | Frontend Mentor Challenge

A Pen created on CodePen.io. Original URL: [https://codepen.io/Shivangi_01/pen/RwMqVwX](https://codepen.io/Shivangi_01/pen/RwMqVwX).

